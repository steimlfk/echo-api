/**
 * New node file
 */

function del(id){
	var r=confirm("Do you really want to delete the user "+id+"?");
	if (r==true)
	{
		var xhr = new XMLHttpRequest();
		xhr.open('DELETE', '/patients/'+id, true);
		xhr.setRequestHeader("Authorization", "Bearer "+token);
		// send the collected data as JSON
		xhr.send();
		xhr.onloadend = function () {
			if (xhr.readyState == 4) {
				document.getElementById(id).style.display = 'none';
//				window.location = '/';
			}
		};
	}
}
var token;
$(document).ready(function() {
	var queryDict = {};
	location.search.substr(1).split("&").forEach(function(item) {queryDict[item.split("=")[0]] = item.split("=")[1]});
	token = queryDict['access_token'];


	var host = window.location.hostname;
	if (host == 'localhost') host = 'localhost:3000';
	$.ajax({
		dataType: "json",
		type: "GET",
		headers: {
			"Authorization": "Bearer "+ token
		},
		url: "http://"+ host+"/patients?sortBy="+queryDict['sortBy']+"&order="+queryDict['order']+"&pageSize="+queryDict['pageSize']+"&page="+queryDict['page'],
		success: function (jason){
			var json = jason.patients;
			if (json.length == 0){
				document.getElementById('msg').innerHMTL = 'No patients found!';
				document.getElementById('tab-patient').style.display = 'none';
			}
			var pgSize = (queryDict['pageSize'] || 20);
			if (json.length < pgSize){
				document.getElementById('btn-next').style.display = 'none';
			}
			var tr;
			for (var i = 0; i < json.length; i++) 
			{
				var dob = json[i].dateOfBirth.split("T")[0];
				tr = $('<tr align=\'left\' id='+json[i].patientId+'/>');
				tr.append("<td>" + json[i].patientId + "</td>");
				tr.append("<td>" + json[i].surname + "</td>");
				tr.append("<td>" + json[i].name + "</td>");
				tr.append("<td>" + dob + "</td>");
				tr.append("<table><tr><td><a class=\"btn btn-success\" href=/views/patients/" + json[i].patientId+ "?access_token="+token+ ">View</a> "+
						"<a class=\"btn btn-warning\" href=/views/patients/edit/" + json[i].patientId+"?access_token="+token+ ">Edit</a> "+
						"<a class=\"btn btn-danger\" onclick=\"del(" +json[i].patientId+")\">Delete</a></td></tr></table>");
				tr.append("</tr>");
				$('#tab-patient').append(tr);
			}
		}
	});
	


	var base = '/views/patients?access_token='+token;
	document.getElementById('id_sort').href 		= base+'&sortBy=patientId';
	document.getElementById('name_sort').href 		= base+'&sortBy=Name';
	document.getElementById('surname_sort').href 	= base+'&sortBy=Surname';
	document.getElementById('birthday_sort').href	= base+'&sortBy=DateOfBirth';
	if (queryDict['page']){
		var pageSize = '&page='+queryDict['page'];
		document.getElementById('id_sort').href += pageSize;
		document.getElementById('name_sort').href += pageSize;
		document.getElementById('surname_sort').href += pageSize;
		document.getElementById('birthday_sort').href += pageSize;
		if (queryDict['pageSize']){
			var page = '&pageSize='+queryDict['pageSize'];
			document.getElementById('id_sort').href += page;
			document.getElementById('name_sort').href += page;
			document.getElementById('surname_sort').href += page;
			document.getElementById('birthday_sort').href += page;
		}
	}

	if (!queryDict['page']){
		document.getElementById('nav').style.display = 'none';
	}
	else {
		var next_page = parseInt(queryDict['page'])+1;
		var back_page = parseInt(queryDict['page'])-1;
		document.getElementById('btn-next').href = '/views/patients?page='+next_page;
		document.getElementById('btn-back').href = '/views/patients?page='+back_page;
		
		if (queryDict['page'] == '1'){
			document.getElementById('btn-back').style.display = 'none';
		}
		if (queryDict['sortBy']){
			document.getElementById('btn-next').href += '&sortBy='+ queryDict['sortBy'];
			document.getElementById('btn-back').href += '&sortBy='+ queryDict['sortBy'];
		}
		if (queryDict['pageSize']){
			document.getElementById('btn-next').href += '&pageSize='+queryDict['pageSize'];
			document.getElementById('btn-back').href += '&pageSize='+queryDict['pageSize'];
		}
	}
	$("a.btn").each(function() {
		var _href = $(this).attr("href");
		if (_href.contains('?')){
		$(this).attr("href", _href + "&access_token="+token);
		}
		else $(this).attr("href", _href + "?access_token="+token);
	});
	
	

	
});

