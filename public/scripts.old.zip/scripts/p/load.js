/**
 * New node file
 */
$(document).ready(function() {
    var id = document.getElementById('ID').value;
    var host = window.location.hostname;
    if (host == 'localhost') host = 'localhost:3000';
	var queryDict = {};
	location.search.substr(1).split("&").forEach(function(item) {queryDict[item.split("=")[0]] = item.split("=")[1]});
	var token = queryDict['access_token'];
	document.getElementById('btn-add-daily').href = '/views/patients/'+id+'/daily-answers';
	$("a.btn").each(function() {
		var _href = $(this).attr("href");
		if (_href.contains('?')){
		$(this).attr("href", _href + "&access_token="+token);
		}
		else $(this).attr("href", _href + "?access_token="+token);
	});
    $.ajax({
        dataType: "json",
        type: "GET",
		headers: {
			"Authorization": "Bearer "+ token
		},
        url: "http://"+ host+"/patients/"+id,
        success: function (json){
            
            var dob = json[0].dateOfBirth.split("T")[0];
            var dod = json[0].firstDiagnose.split("T")[0];
            var notes = json[0].notes;
            notes = notes.replace(/\\r\\n/g, "<br />");
            notes = notes.replace(/\n/g, "<br />");
            
            document.getElementById('Surname').innerHTML             = json[0].surname;
            document.getElementById('Name').innerHTML                = json[0].name;
            document.getElementById('SecondName').innerHTML          = json[0].secondName;
            document.getElementById('IDNumber').innerHTML            = json[0].idNumber;
            document.getElementById('Sex').innerHTML                 = json[0].sex;
            document.getElementById('DateOfBirth').innerHTML         = dob;
            document.getElementById('Size').innerHTML                = json[0].size;
            document.getElementById('Weight').innerHTML              = json[0].weight;
            document.getElementById('DiagnoseDate').innerHTML        = dod
            document.getElementById('FileNo').innerHTML             = json[0].fileNo;
            document.getElementById('Hospital').innerHTML            = json[0].hospital;
            document.getElementById('Smoker').innerHTML              = json[0].smoker;
            document.getElementById('PxY').innerHTML                 = json[0].pxy;
            document.getElementById('Notes').innerHTML               = notes;
            document.getElementById('Trial').innerHTML               = json[0].trial;
            document.getElementById('Choice').innerHTML              = json[0].optional;
            

            }
    });
    
    $.ajax({
        dataType: "json",
        type: "GET",
		headers: {
			"Authorization": "Bearer "+ token
		},
        url: "http://"+ host+"/patients/"+id+"/daily-answers",
        success: function (json){
			if (json == null){
				document.getElementById('tab-daily-answers').style.display = 'none';
			} 
			else {
			var tr;
			for (var i = 0; i < json.length; i++) 
			{
				
				tr = $('<tr align=\'left\' />');
				tr.append("<td>" + json[i].idQuestions + "</td>");
				tr.append("<td>" + json[i].date + "</td>");
				tr.append("<td>" + json[i].text + "</td>");
				tr.append("<td>" + json[i].score + "</td>");
				
				$('#tab-daily-answers').append(tr);
			}
			}
			
        }
    });
    
    $.ajax({
        dataType: "json",
        type: "GET",
		headers: {
			"Authorization": "Bearer "+ token
		},
        url: "http://"+ host+"/patients/"+id+"/ccqweek",
        success: function (json){
			if (json.length == 0){
				document.getElementById('tab-ccq').style.display = 'none';
			} 
			var tr;
			for (var i = 0; i < json.length; i++) 
			{
				var date = json[i].DiagnoseDate.split("T")[0];
				tr = $('<tr align=\'left\' />');
				tr.append("<td>" + date + "</td>");
				tr.append("<td>" + json[i].Total_CCQ_Score + "</td>");
				tr.append("<td>" + json[i].Symptom_Score + "</td>");
				tr.append("<td>" + json[i].Mental_State_Score + "</td>");
				tr.append("<td>" + json[i].Functional_State_Score + "</td>");
				
				$('#tab-ccq').append(tr);
			}
        }
    });
    
    $.ajax({
        dataType: "json",
        type: "GET",
		headers: {
			"Authorization": "Bearer "+ token
		},
        url: "http://"+ host+"/patients/"+id+"/charlson",
        success: function (json){
			if (json.length == 0){
				document.getElementById('tab-charlson').style.display = 'none';
			} 
			var tr;
			for (var i = 0; i < json.length; i++) 
			{
				var date = json[i].DiagnoseDate.split("T")[0];
				tr = $('<tr align=\'left\' />');
				tr.append("<td>" + date + "</td>");
				tr.append("<td>" + json[i].Total_Charlson + "</td>");
				
				$('#tab-charlson').append(tr);
			}
        }
    });
    
    $.ajax({
        dataType: "json",
        type: "GET",
		headers: {
			"Authorization": "Bearer "+ token
		},
        url: "http://"+ host+"/patients/"+id+"/catscale",
        success: function (json){
			if (json.length == 0){
				document.getElementById('tab-catscale').style.display = 'none';
			} 
			var tr;
			for (var i = 0; i < json.length; i++) 
			{
				var date = json[i].diagnoseDate.split("T")[0];
				tr = $('<tr align=\'left\' />');
				tr.append("<td>" + date + "</td>");
				tr.append("<td>" + json[i].catscale + "</td>");
				
				$('#tab-catscale').append(tr);
			}
        }
    });
    
    $.ajax({
        dataType: "json",
        type: "GET",
		headers: {
			"Authorization": "Bearer "+ token
		},
        url: "http://"+ host+"/patients/"+id+"/fagerstrom",
        success: function (json){
			if (json.length == 0){
				document.getElementById('tab-fagerstrom').style.display = 'none';
			} 
			var tr;
			for (var i = 0; i < json.length; i++) 
			{
				var date = json[i].DiagnoseDate.split("T")[0];
				tr = $('<tr align=\'left\' />');
				tr.append("<td>" + date + "</td>");
				tr.append("<td>" + json[i].Fagerstrom_Score + "</td>");
				
				$('#tab-fagerstrom').append(tr);
			}
        }
    });

    
    $.ajax({
        dataType: "json",
        type: "GET",
		headers: {
			"Authorization": "Bearer "+ token
		},
        url: "http://"+ host+"/patients/"+id+"/cessation-intervention",
        success: function (json){
			if (json.length == 0){
				document.getElementById('tab-CessationIntervention').style.display = 'none';
			} 
			var tr;
			for (var i = 0; i < json.length; i++) 
			{
				var date = json[i].DiagnoseDate.split("T")[0];
				tr = $('<tr align=\'left\' />');
				tr.append("<td>" + date + "</td>");
				tr.append("<td>" + json[i].CurrentSmoking + "</td>");
				tr.append("<td>" + json[i].Zyban + "</td>");
				tr.append("<td>" + json[i].Champix+ "</td>");
				tr.append("<td>" + json[i].NicotineReplacement + "</td>");
				tr.append("<td>" + json[i].NicotineKind + "</td>");
				tr.append("<td>" + json[i].NicotineDose + "</td>");
				tr.append("<td>" + json[i].Behavioural + "</td>");
				tr.append("</tr>");
				$('#tab-CessationIntervention').append(tr);
			}
        }
    });
});
       
