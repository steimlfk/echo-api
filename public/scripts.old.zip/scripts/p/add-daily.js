

$(document).ready(function() {
	var id = document.getElementById('ID').value;
	var host = window.location.hostname;
	if (host == 'localhost') host = 'localhost:3000';
	
	var queryDict = {};
	location.search.substr(1).split("&").forEach(function(item) {queryDict[item.split("=")[0]] = item.split("=")[1]});
	var token = queryDict['access_token'];
	$("a.btn").each(function() {
		var _href = $(this).attr("href");
		if (_href.contains('?')){
		$(this).attr("href", _href + "&access_token="+token);
		}
		else $(this).attr("href", _href + "?access_token="+token);
	});
	
	$.ajax({
		dataType: "json",
		type: "GET",
		headers: {
			"Authorization": "Bearer "+ token
		},
		url: "http://"+ host+"/questions?category=daily",
		success: function (json){
			if (json == null){
				$('#questions').hide()
			} 
			else {
				var tr;
				for (var i = 0; i < json.length; i++) 
				{
					tr = $('<tr align=\'left\' />');
					tr.append("<td colspan="+json[i].answers.length+"><h3>"+json[i].text+"</h3></td>");
					var tr_text = $('<tr align=\'left\' />');
					var tr_values = $('<tr align=\'left\' />');
					for (var j = 0; j < json[i].answers.length; j++){
						tr_text.append("<td class='answer' align='center'>"+json[i].answers[j].text+"</td>");
						tr_values.append("<td class='answer'  align='center'><input type=\"radio\" name=\""+ json[i].questionId+"\" value="+json[i].answers[j].value+"></td>");
					}
					tr_text.append("</tr>");
					tr_values.append("</tr>");
					tr.append("</tr>");
					$('#questions').append(tr);
					$('#questions').append(tr_text);
					$('#questions').append(tr_values);
				}
			}
		}
	});

	$.ajax({
		dataType: "json",
		type: "GET",
		headers: {
			"Authorization": "Bearer "+ token
		},
		url: "http://"+ host+"/patients/"+id,
		success: function (json){

		}
	});

});