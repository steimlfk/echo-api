/**
 * New node file
 */
$(document).ready(function() {
	var id = document.getElementById('ID').value;
	var host = window.location.hostname;
	if (host == 'localhost') host = 'localhost:3000';
	
	var queryDict = {};
	location.search.substr(1).split("&").forEach(function(item) {queryDict[item.split("=")[0]] = item.split("=")[1]});
	var token = queryDict['access_token'];
	$("a.btn").each(function() {
		var _href = $(this).attr("href");
		if (_href.contains('?')){
		$(this).attr("href", _href + "&access_token="+token);
		}
		else $(this).attr("href", _href + "?access_token="+token);
	});
		
	$.ajax({
		dataType: "json",
		type: "GET",
		headers: {
			"Authorization": "Bearer "+ token
		},
		url: "http://"+ host+"/patients/"+id,
		success: function (json){

			var dob = json[0].DateOfBirth.split("T")[0];
			var dod = json[0].DiagnoseDate.split("T")[0];
			document.getElementById('Surname').value             = json[0].Surname;
			document.getElementById('Name').value                = json[0].Name;
			document.getElementById('SecondName').value          = json[0].SecondName;
			document.getElementById('IDNumber').value            = json[0].IDNumber;
			document.getElementById('Sex').value                 = json[0].Sex;
			document.getElementById('DateOfBirth').value         = dob;
			document.getElementById('Size').value                = json[0].Size;
			document.getElementById('Weight').value              = json[0].Weight;
			document.getElementById('DiagnoseDate').value        = dod
			document.getElementById('FileNo').value             = json[0].FileNo;
			document.getElementById('Hospital').value            = json[0].Hospital;
			document.getElementById('Smoker').value              = json[0].Smoker;
			document.getElementById('PxY').value                 = json[0].PxY;
			document.getElementById('Notes').value               = json[0].Notes;
			document.getElementById('Trial').value               = json[0].Trial;
			document.getElementById('Choice').value              = json[0].Choice;


		}
	});

});

