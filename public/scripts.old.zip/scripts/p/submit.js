/**
 * New node file
 */

function isInt(value) {
	return !isNaN(value) && parseInt(value) == value;
}

$(document).ready(function(){
	var host = window.location.hostname;
	if (host == 'localhost') host = 'localhost:3000';
	//http://stackoverflow.com/questions/1255948/post-data-in-json-format-with-javascript

	var queryDict = {};
	location.search.substr(1).split("&").forEach(function(item) {queryDict[item.split("=")[0]] = item.split("=")[1]});
	var token = queryDict['access_token'];
	$("a.btn").each(function() {
		var _href = $(this).attr("href");
		if (_href.contains('?')){
		$(this).attr("href", _href + "&access_token="+token);
		}
		else $(this).attr("href", _href + "?access_token="+token);
	});
	
	var form = document.getElementById('Editform');

	var meth = 'POST';
	var action = '/patients/';
	if (document.getElementById('ID') != null) {
		meth = 'PUT'; 
		var id = document.getElementById('ID').value;
		action = '/patients/'+id;
	}


	form.onsubmit = function (e) {
		// stop the regular form submission
		e.preventDefault();

		var err = false;
		if (!isInt(document.getElementById('IDNumber').value)) err = true;  
		if (!isInt(document.getElementById('Size').value )) err = true;  
		if (!isInt(document.getElementById('Weight').value )) err = true;  
		if (!isInt(document.getElementById('PxY').value )) err = true;  
		if (!isInt(document.getElementById('FileNo').value )) err = true;
		if (err){
			alert ('Check your Inputs');
			return;
		}

		// collect the form data while iterating over the inputs
		var data = {};
		for (var i = 0, ii = form.length; i < ii; ++i) {
			var input = form[i];
			
			if (input.id) {
				if (input.id != 'ID') 
					if (input.id != 'Choice')
						data[input.id] = input.value;
					else 
						data['choice'] = (input.value == 'on') ? 1 : 0;
				else
					data['patientId'] = input.value;
			}
		}

		// construct an HTTP request
		var xhr = new XMLHttpRequest();
		xhr.open(meth, action, true);
		xhr.setRequestHeader('Content-Type', 'application/json; charset=UTF-8');
		xhr.setRequestHeader("Authorization", "Bearer "+token);
		// send the collected data as JSON
		xhr.send(JSON.stringify(data));
		
		xhr.onloadend = function () {
			if (xhr.readyState == 4) {
				if (document.getElementById('ID') != null) {
					document.getElementById('msg').innerHTML = "User updated. <a href=/views/patients?limit=20&access_token="+token +">Back<a>"
				}
				else document.location = '/views/patients?limit=20&access_token='+token;

			}
		};
		//window.location = '/views/patients/'
	};


	
	var select = document.getElementById('Sex');
	var o = document.createElement("option");
	o.value = 'A';
	o.text = 'A';
	select.appendChild(o);
	o = document.createElement("option");
	o.value = 'Γ';
	o.text = 'Γ';
	select.appendChild(o);
	
	$.ajax({
		dataType: "json",
		type: "GET",
		headers: {
			"Authorization": "Bearer "+ token
		},
		url: "http://"+ host+"/hospitals/",
		success: function (json){
			var select = document.getElementById('Hospital');
			for (var i = 0; i < json.length; i++) {
				var o = document.createElement("option");
				o.value = json[i].hospital;
				o.text = json[i].hospital;
				select.appendChild(o);
			}
		}
	});
	
	$.ajax({
		dataType: "json",
		type: "GET",
		headers: {
			"Authorization": "Bearer "+ token
		},
		url: "http://"+ host+"/smokerstatus/",
		success: function (json){
			var select = document.getElementById('Smoker');
			for (var i = 0; i < json.length; i++) {
				var o = document.createElement("option");
				o.value = json[i].Smoking;
				o.text = json[i].Smoking;
				select.appendChild(o);
			}
		}
	});


}

);