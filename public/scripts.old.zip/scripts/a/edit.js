/**
 * New node file
 */
$(document).ready(function() {
	var id = document.getElementById('ID').value;
	var queryDict = {};
	location.search.substr(1).split("&").forEach(function(item) {queryDict[item.split("=")[0]] = item.split("=")[1]});
	var token = queryDict['access_token'];
	
	$("a.btn").each(function() {
		var _href = $(this).attr("href");
		if (_href.contains('?')){
		$(this).attr("href", _href + "&access_token="+token);
		}
		else $(this).attr("href", _href + "?access_token="+token);
	});
	
	var host = window.location.hostname;
	if (host == 'localhost') host = 'localhost:3000';
		
	$.ajax({
		dataType: "json",
		type: "GET",
		headers: {
			"Authorization": "Bearer "+ token
		},
		url: "http://"+ host+"/accounts/"+id,
		success: function (json){

			document.getElementById('Username').value             			= json[0].user;
			document.getElementById('Password').value                		= json[0].password;
			document.getElementById('Password_Verification').value          = json[0].password;
			document.getElementById('EMail').value            				= json[0].email;
			document.getElementById('Role').value                 			= json[0].role;



		}
	});

});

