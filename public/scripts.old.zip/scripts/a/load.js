/**
 * New node file
 */
$(document).ready(function() {
	var queryDict = {};
	location.search.substr(1).split("&").forEach(function(item) {queryDict[item.split("=")[0]] = item.split("=")[1]});
	var token = queryDict['access_token'];
	$("a.btn").each(function() {
		var _href = $(this).attr("href");
		if (_href.contains('?')){
		$(this).attr("href", _href + "&access_token="+token);
		}
		else $(this).attr("href", _href + "?access_token="+token);
	});
	var id = document.getElementById('ID').value;
	var host = window.location.hostname;
	if (host == 'localhost') host = 'localhost:3000';
	$.ajax({
		dataType: "json",
		type: "GET",
		headers: {
			"Authorization": "Bearer "+ token
		},
		url: "http://"+ host+"/accounts/"+id,
		success: function (json){

			document.getElementById('User').innerHTML             = json[0].user;
			document.getElementById('Mail').innerHTML                 = json[0].email;
			document.getElementById('Role').innerHTML               = json[0].role;


		}
	});
});

