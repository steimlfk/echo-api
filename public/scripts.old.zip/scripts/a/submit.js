/**
 * New node file
 */

function isInt(value) {
	return !isNaN(value) && parseInt(value) == value;
}

$(document).ready(function(){
	
	var queryDict = {};
	location.search.substr(1).split("&").forEach(function(item) {queryDict[item.split("=")[0]] = item.split("=")[1]});
	var token = queryDict['access_token'];
	
	var host = window.location.hostname;
	if (host == 'localhost') host = 'localhost:3000';
	//http://stackoverflow.com/questions/1255948/post-data-in-json-format-with-javascript

	$("a.btn").each(function() {
		var _href = $(this).attr("href");
		if (_href.contains('?')){
		$(this).attr("href", _href + "&access_token="+token);
		}
		else $(this).attr("href", _href + "?access_token="+token);
	});
	
	var form = document.getElementById('Editform');

	var meth = 'POST';
	var action = '/accounts/';
	if (document.getElementById('ID') != null) {
		meth = 'PUT'; 
		var id = document.getElementById('ID').value;
		action = '/accounts/'+id;
	}
	
	var select = document.getElementById('Role');
	var roles = ['admin', 'doctor', 'patient'];
	for (var i = 0; i < roles.length; i++){
		var o = document.createElement("option");
		o.value = roles[i];
		o.text = roles[i];
		select.appendChild(o);
	}


	form.onsubmit = function (e) {
		// stop the regular form submission
		e.preventDefault();

		var err = false;
		if (document.getElementById('Password').value != document.getElementById('Password_Verification').value) err = true;  

		if (err){
			alert ('Check your Password');
			return;
		}

		// collect the form data while iterating over the inputs
		var data = {};
		for (var i = 0, ii = form.length; i < ii; ++i) {
			var input = form[i];
			if (input.id) {
				if (input.id == 'ID') 
					data['accountId'] = input.value;
				if (input.id == 'Username') 
					data['user'] = input.value;
				if (input.id == 'Password') 
					data['password'] = input.value;
				if (input.id == 'Role') 
					data['role'] = input.value;
				if (input.id == 'EMail') 
					data['email'] = input.value;
			}
		}

		// construct an HTTP request
		var xhr = new XMLHttpRequest();
		xhr.open(meth, action, true);
		xhr.setRequestHeader('Content-Type', 'application/json; charset=UTF-8');
		xhr.setRequestHeader("Authorization", "Bearer "+token);
		// send the collected data as JSON
		xhr.send(JSON.stringify(data));

		xhr.onloadend = function () {
			if (xhr.readyState == 4) {
				if (document.getElementById('ID') != null) {
					document.getElementById('msg').innerHTML = "Account updated. <a href=/views/accounts?limit=20&access_token="+token+" >Back<a>"
				}
				else document.location = '/views/accounts?limit=20&access_token='+token ;

			}
		};
		//window.location = '/views/patients/'
	};


}

);