/**
 * New node file
 */
$(document).ready(function() {
	var queryDict = {};
	location.search.substr(1).split("&").forEach(function(item) {queryDict[item.split("=")[0]] = item.split("=")[1]});
	if (queryDict['msg']) $('#msg').text(queryDict['msg'].replace(/_/g,' '));
	$("#loginform").submit(function( event ) {
		event.preventDefault();
		var user = $('input[name="username"]').val();
		var pwd = $('input[name="password"]').val();

		var host = window.location.hostname;
		if (host == 'localhost') host = 'localhost:3000';
		var token;
		$.ajax({
			async: false,
			headers: {
				"Authorization": "Basic "+  btoa(user + ":" + pwd)
			},
			type: "POST",
			url: "http://"+ host+"/login/",
			success: function (json, status, jqXHR){
				token = json.token;
				window.location.href = '/views/home?access_token='+token;
			},
			error: function(json, status, jqXHR){
				$('#msg').text('Invalid Credentials!');
			}
		});
		
		
		
		
	});
});