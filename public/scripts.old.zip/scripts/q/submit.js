/**
 * New node file
 */

function isInt(value) {
	return !isNaN(value) && parseInt(value) == value;
}

$(document).ready(function(){
	var host = window.location.hostname;
	if (host == 'localhost') host = 'localhost:3000';
	
	var queryDict = {};
	location.search.substr(1).split("&").forEach(function(item) {queryDict[item.split("=")[0]] = item.split("=")[1]});
	var token = queryDict['access_token'];
	$("a.btn").each(function() {
		var _href = $(this).attr("href");
		if (_href.contains('?')){
		$(this).attr("href", _href + "&access_token="+token);
		}
		else $(this).attr("href", _href + "?access_token="+token);
	});
	
	$.ajax({
		dataType: "json",
		type: "GET",
		headers: {
			"Authorization": "Bearer "+ token
		},
		url: "http://"+ host+"/questions/categories",
		success: function (json){
			var select = document.getElementById('category');
			for (var i = 0; i < json.categories.length; i++) {
				var o = document.createElement("option");
				o.value = json.categories[i];
				o.text =json.categories[i];
				select.appendChild(o);
			}
		}
	});
	
	

	$.ajax({
		dataType: "json",
		type: "GET",
		headers: {
			"Authorization": "Bearer "+ token
		},
		url: "http://"+ host+"/questions/types",
		success: function (json){
			var select = document.getElementById('type');
			for (var i = 0; i < json.types.length; i++) {
				var o = document.createElement("option");
				o.value = json.types[i];
				o.text = json.types[i];
				select.appendChild(o);
			}
		}
	});

	document.getElementById("add_cat").onclick = function(){
		var new_cat = prompt("Please enter new Category","new Category");
		if (new_cat!=null){
			var select = document.getElementById('category');
			var o = document.createElement("option");
			o.value = new_cat;
			o.text =new_cat;
			select.appendChild(o);
			select.value =new_cat;
		}
	}

	document.getElementById("add_type").onclick = function(){
		var new_cat = prompt("Please enter new Type","new Type");
		if (new_cat!=null){
			var select = document.getElementById('type');
			var o = document.createElement("option");
			o.value = new_cat;
			o.text =new_cat;
			select.appendChild(o);
			select.value =new_cat;
		}
	}

	$(document).on('click', "input.btn-add", function() {

		$("input.btn-add").hide();
		var row = document.getElementById('add-question').insertRow(-1);
		row.insertCell(0);
		var cell1 = row.insertCell(1);
		row.cells[0].innerHTML = "Answer " + ++ctr; ;
		var element1 = document.createElement("input");
		element1.type = "text";
//		element1.name = "txtbox[]";
		element1.className = "question-text";
		element1.id = ctr;
		cell1.appendChild(element1);
		var cell2 = row.insertCell(2);
		var element2 = document.createElement("input");
		element2.type = "text";
//		element2.name = "txtbox[]";
		element2.id = ctr;
		element2.className = "question-value";
		cell2.appendChild(element2);
		var cell3 = row.insertCell(3);
		var element3 = document.createElement("input");
		element3.type = "button";
		element3.value  = "Add";
		element3.className = "btn btn-success btn-add";
		cell3.appendChild(element3);
	});

	var form = document.getElementById('Editform');
	form.onsubmit = function (e) {
		// stop the regular form submission
		e.preventDefault();
		// collect the form data while iterating over the inputs
		var data = {};
		data['answers'] = new Array();
		for (var i = 0, ii = form.length; i < ii; ++i) {
			var input = form[i];
			if(input.type != 'button' && input.type != 'submit'){
				if (input.className == 'question-text'){
					if (!data['answers'][parseInt(input.id)-1]) data['answers'][parseInt(input.id)-1] = {};
					data['answers'][parseInt(input.id)-1]['answertext'] = input.value;
				}
				else if (input.className  == 'question-value'){
					if (!data['answers'][parseInt(input.id)-1]) data['answers'][parseInt(input.id)-1] ={};
					data['answers'][parseInt(input.id)-1]['value'] = input.value;
				}
				else data[input.id] = input.value;  
			}
		} 
		alert(token);
		var xhr = new XMLHttpRequest();
		xhr.open('POST', '/questions', true);
		xhr.setRequestHeader('Content-Type', 'application/json; charset=UTF-8');
		xhr.setRequestHeader('Authorization', 'Bearer '+token);
		// send the collected data as JSON
		xhr.send(JSON.stringify(data));

		xhr.onloadend = function () {
			if (xhr.readyState == 4) {
//				if (document.getElementById('ID') != null) {
//				document.getElementById('msg').innerHTML = "User updated. <a href=/ >Back<a>"
//				}
//				else 
				document.location = '/views/questions?access_token='+token;

			}
		};

	}

}

);
var ctr = 2;