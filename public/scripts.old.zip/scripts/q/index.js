/**
 * New node file
 */
$(document).ready(function() {
	var host = window.location.hostname;
	if (host == 'localhost') host = 'localhost:3000';
	
	var queryDict = {};
	location.search.substr(1).split("&").forEach(function(item) {queryDict[item.split("=")[0]] = item.split("=")[1]});
	var token = queryDict['access_token'];
	$("a.btn").each(function() {
		var _href = $(this).attr("href");
		if (_href.contains('?')){
		$(this).attr("href", _href + "&access_token="+token);
		}
		else $(this).attr("href", _href + "?access_token="+token);
	});
	
	$.ajax({
		dataType: "json",
		type: "GET",
		headers: {
			"Authorization": "Bearer "+ token
		},
		url: "http://"+ host+"/questions?sortBy=category",
		success: function (json){
			if (json.length == 0){
				document.getElementById('msg').innerHMTL = 'No questions found!';
				document.getElementById('tab-questions').style.display = 'none';
			}
			var tr;
			var cat_change = true;
			for (var i = 0; i < json.length; i++) 
			{
				if (cat_change){
					tr = $('<tr align=\'left\'/>');
					tr.append("<td><h2>"+ json[i].category + "</h2></td>");
					tr.append("</tr>");
					$('#tab-questions').append(tr);
					tr = $('<tr><td><table id='+json[i].category+'></table></td></tr>');
					$('#tab-questions').append(tr);
					tr = $('<tr><th align=\'left\'>id</th><th align=\'left\'>Active?</th><th align=\'left\'>Text</th><th align=\'left\'>Answers</th></tr>');
					$('#'+json[i].category).append(tr);
					cat_change = false;
				}
				tr = $('<tr align=\'left\' id='+json[i].questionId+'>');
				tr.append("<td class=question>"+ json[i].questionId +"</td>");
				tr.append("<td class=question>"+ json[i].active +"</td>");
				tr.append("<td class=question>"+ json[i].text +"</td>");
				tr.append("<td class=question>(" + json[i].answers[0].value +") "+ json[i].answers[0].text +"</td>");
				tr.append("</tr>");
				$('#'+json[i].category).append(tr);
				
				
				for (var k = 1; k< json[i].answers.length; k++){
					$('#'+json[i].category).append('<tr align=\'left\'/><td colspan=3></td><td align=\'left\'>(' + json[i].answers[k].value +') '+ json[i].answers[k].text +'</td></tr>');
				}

				if (i < json.length-1){ 
					if (json[i+1].category != json[i].category){
						cat_change = true;
					}
				}
			}
		}
	});
});